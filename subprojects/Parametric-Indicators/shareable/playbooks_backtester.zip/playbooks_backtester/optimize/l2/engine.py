"""L2 Pass 2 — run the secondary profile over the dropped signals, reusing the EXACT fast_backtest
exit math. L2 may open only at dropped bars where L1 is flat AND L2's own gate passes; any L2 trade
overlapping a later L1 entry is force-closed at that bar (L1 priority). Direction = box direction,
optionally reversed by L2's flip ('reverse is implicit')."""
from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np

_PI = Path(__file__).resolve().parents[2]
if str(_PI) not in sys.path:
    sys.path.insert(0, str(_PI))

from optimize.fast_engine import fast_backtest                     # noqa: E402
from optimize.l2.l1_runner import apply_breaker                    # noqa: E402
from optimize import instruments                                   # noqa: E402
from indicators import library, runner                             # noqa: E402
from volatility import gate_threshold                              # noqa: E402


def _cached_1min_source(l1):
    """The 1-MINUTE indicator source (ctx_1min, j_idx) for this L1 run, memoised ON the l1 object.
    It is a pure function of l1's frozen data (df_dec/df1/bar_td), so rebuilding it every optimizer trial
    — the heavy market_context(df1) numpy conversion + the searchsorted decbar→1min map — is wasted work
    (mirrors the ES contributor's gate._cached_source, which the comment there notes saved ~75s/trial).
    Computed lazily post-load so it never enters the L1 disk-cache pickle. Result-neutral by construction."""
    src = getattr(l1, "_l2_min_src", None)
    if src is None:
        src = runner.indicator_source_1min(l1.df_dec, l1.df1, l1.bar_td)
        try:
            l1._l2_min_src = src                          # attach to the in-process L1Result (not pickled)
        except Exception:
            pass                                          # read-only l1 (unexpected) → just don't cache
    return src


def _committee_votes(l1, inds, src) -> dict:
    """compute_votes drop-in (dict keyed by id(ind)) with a per-l1 memo. A given indicator's vote array
    is a pure function of (1-min-mode?, key, mode, params) for this frozen l1, so identical configs across
    trials (Optuna revisits the search space heavily; SMC ifvg/breaker are ~90% of per-trial cost) are
    computed ONCE and reused. Returned arrays are treated read-only downstream (veto/confirm masks copy),
    so sharing them is safe. Result-neutral: same call as runner.compute_votes, just cached."""
    enabled = [ind for ind in inds if ind.config.enabled]
    if not enabled:
        return {}
    from optimize import vote_cache
    from optimize.core import _slice_sig
    memo = getattr(l1, "_l2_vote_memo", None)
    if memo is None:
        memo = {}
        try:
            l1._l2_vote_memo = memo
        except Exception:
            memo = None                                   # read-only l1 → compute without in-memory caching
    use1 = src is not None
    base = _slice_sig(l1.df_dec, l1.df1, l1.bar_td)        # L1-frame signature for the disk key
    ctx = bdir = None                                     # built lazily, only on a real (memo+disk) miss
    out = {}
    for ind in enabled:
        c = ind.config
        params_t = tuple(sorted(c.params.items()))
        sig = (use1, ind.key, c.mode, params_t)           # in-memory key (per-l1; no slice needed)
        v = memo.get(sig) if memo is not None else None
        if v is None:
            dkey = vote_cache.disk_key(base, use1, ind.key, c.mode, params_t)
            v = vote_cache.get(dkey)
            if v is None:
                if ctx is None:
                    ctx = runner.market_context(l1.df_dec)
                    bdir = runner.box_direction_int(l1.df_dec, l1.box)
                v = runner._ind_vote(ind, ctx, bdir, src)
                vote_cache.put(dkey, v)
            if memo is not None:
                memo[sig] = v
        out[id(ind)] = v
    return out


def _nq_components(l1, l2_params: dict):
    """NQ's raw L2 gate ingredients: (vol_gate, veto, confirm, confirm_count_entry, k_eff, n_confirmers).
    Superset of l2_gate_components — also returns the entry-shifted confirm COUNT (cc_entry[i] = #confirms
    at bar i-1, idx0=0), k_eff=min(k,#confirmers), and #confirmers, for the topology-pooling combiner.
    `confirm` == runner.confirm_mask exactly. Single source of truth for both the mask and the count."""
    from indicators.base import CONFIRM
    d, d1, box = l1.df_dec, l1.df1, l1.box
    n = len(d)
    gate_pct = float(l2_params.get("gate_pct", 0.0))
    K = int(l2_params.get("k", 1))
    vol_gate = np.ones(n, dtype=bool)
    if gate_pct > 0:
        # seed on L1's IN-SAMPLE prefix (vf_seed), NOT l1.vf[:n_split] — the latter is the WINDOWED vf,
        # so for a 2026 window it would reseed on out-of-sample data and diverge.
        seed = l1.vf_seed if l1.vf_seed is not None else l1.vf[:l1.n_split]
        gthr = gate_threshold(seed, len(seed), gate_pct)
        vol_gate = l1.vf[:n] <= gthr
    veto = np.zeros(n, dtype=bool)
    confirm = np.ones(n, dtype=bool)
    cc_entry = np.zeros(n, dtype=np.int64)
    k_eff = 0
    n_confirmers = 0
    specs = [s for s in l2_params.get("indicators", []) if s.get("enabled")]
    if specs:
        inds = library.from_specs(specs)
        src = _cached_1min_source(l1) if l2_params.get("ind_1min") else None
        votes = _committee_votes(l1, inds, src)
        veto = np.asarray(runner.veto_mask(d, box, inds, src=src, votes=votes), dtype=bool)[:n]
        confirm = np.asarray(runner.confirm_mask(d, box, inds, K, src=src, votes=votes), dtype=bool)[:n]
        confirmers = [i for i in inds if i.config.enabled and i.config.mode in ("confirm", "both")]
        n_confirmers = len(confirmers)
        k_eff = min(K, n_confirmers)
        if k_eff > 0:
            cc = np.zeros(n, dtype=np.int64)
            for ind in confirmers:
                cc += (votes[id(ind)] == CONFIRM).astype(np.int64)
            cc_entry[1:] = cc[:-1]                  # entry-shift (confirms read at idx-1); idx0=0
    return vol_gate, veto, confirm, cc_entry, k_eff, n_confirmers


def l2_gate_components(l1, l2_params: dict):
    """L2's per-bar gate components (vol_gate, veto, confirm) — UNCHANGED public shape, used by the causal
    log builder to attribute WHY L2 declined a bar; `_l2_gate_masks` ANDs them. Delegates to
    `_nq_components` so the mask and the topology-count path share one source of truth."""
    vol_gate, veto, confirm, _, _, _ = _nq_components(l1, l2_params)
    return vol_gate, veto, confirm


def _l2_gate_masks(l1, l2_params: dict) -> np.ndarray:
    """L2's own per-bar eligibility = vol_gate ∧ ¬veto ∧ confirm≥K (the ANDed components)."""
    vol_gate, veto, confirm = l2_gate_components(l1, l2_params)
    return vol_gate & ~veto & confirm


def force_close_on_l1_entry(cand: list[dict], l1_entries, dec_dates: np.ndarray,
                            dec_close: np.ndarray, pv: float) -> list[dict]:
    """Truncate each candidate at the earliest L1 entry STRICTLY inside (entry_idx, exit_bar). Exit at
    that bar's close, reason 'L1-entry'; P/L recomputed honestly (never dropped)."""
    l1_entries = sorted(int(j) for j in l1_entries)
    out = []
    for t in cand:
        e = int(t["entry_idx"])
        xb = int(np.searchsorted(dec_dates, np.datetime64(t["exit_time"]), side="left"))
        xb = max(xb, e + 1)
        hit = next((j for j in l1_entries if e < j < xb), None)
        if hit is None:
            out.append(t)
            continue
        ep = float(t["entry_price"])
        xp = float(dec_close[hit])
        pts = (xp - ep) if t["direction"] == "long" else (ep - xp)
        tt = dict(t)
        tt["exit_time"] = dec_dates[hit]
        tt["exit_price"] = xp
        tt["exit_reason"] = "L1-entry"
        tt["pnl_points"] = pts
        out.append(tt)
    return out


def _l2_eligibility(l1, l2_params: dict) -> np.ndarray:
    """L2 per-bar eligibility (vol_gate ∧ ¬veto ∧ confirm) combined with enabled cross-instrument
    contributors per topology (Spec §6). Veto is always any-OR. CONFIRM combines by topology:
      separate_and — NQ ∧ each (contrib_count >= k_es)   (a contributor must ALSO agree)
      merged       — pooled (NQ + contributor) confirm count >= min(k, #sources)
      or_boost     — NQ ∨ any (contrib_count >= k_es)     (a contributor confirm can rescue a bar)
    A contributor with no confirm source (sentinel count) adds no confirm in any topology, so
    no-enabled-contributor ⇒ exactly the NQ gate ⇒ byte-identical contributor-free L2."""
    vol_gate, nq_veto, nq_confirm, nq_cc, k_eff, nq_nconf = _nq_components(l1, l2_params)
    n = len(vol_gate)
    contribs = [c for c in (l2_params.get("contributors") or []) if c.get("enabled")]
    if not contribs:
        return vol_gate & ~nq_veto & nq_confirm
    from optimize.l2.contributors import gate as cg, combine
    topo = str(l2_params.get("contributor_topology", "separate_and"))
    veto = nq_veto.copy()
    parsed = []                                              # (confirm_count, k_es, has_confirm)
    for cfg in contribs:
        cveto, ccount = cg.contributor_gate_masks(cfg, l1)
        veto |= cveto
        has_confirm = not bool((ccount == cg.NO_CONFIRM_CONSTRAINT).all())
        parsed.append((ccount, int(cfg.get("k_es", 1)), has_confirm))
    # one shared topology-combine (contributors/combine.py) — same logic the L1 fast path uses
    return combine.combine_eligibility(vol_gate, veto, nq_confirm, nq_cc,
                                       int(l2_params.get("k", 1)), nq_nconf, parsed, topo)


@dataclass
class L2Result:
    params: dict
    ledger: list
    n_skipped_breaker: int
    n_locks: int
    n_l1_entry_exits: int


def run_l2(l1, l2_params: dict, bar_mask=None, exit_mode: str = "l1_priority") -> L2Result:
    """exit_mode (spec round 1 vs 2):
      'l1_priority' (default, round 1) — when L1 opens during an L2 trade, L2 force-closes (reason
                     'L1-entry'); L1 wins ties.
      'keep_l2'     (round 2 A/B)      — L2 keeps its position to its own SL/TP; the overlapping L1 trade
                     yields. (The combined book then drops the overlapped L1 trades — see round2.compare.)"""
    if exit_mode not in ("l1_priority", "keep_l2"):
        raise ValueError(f"exit_mode must be 'l1_priority' or 'keep_l2' (got {exit_mode!r})")
    d, d1 = l1.df_dec, l1.df1
    n = len(d)
    dec_dates = d["Date"].to_numpy()
    dec_close = d["Close"].to_numpy(float)
    pv = float(instruments.point_value(getattr(l1, "instrument", "NQ")))

    dropped_mask = np.zeros(n, dtype=bool)
    for ds in l1.dropped_signals:
        dropped_mask[int(ds["idx"])] = True
    l1_flat = ~l1.state_timeline
    l2_gate = dropped_mask & l1_flat & _l2_eligibility(l1, l2_params)   # NQ gate + contributors (topology)
    if bar_mask is not None:                                  # window L2 to a bar range (in-sample / OOS)
        l2_gate = l2_gate & np.asarray(bar_mask, dtype=bool)[:n]

    # E3a: intra-candle entry timing for the VETOED stream. When on, vetoed candidates enter mid-candle at
    # the first 1-min bar L1's veto clears (within N) instead of the candle close; vol-gated stream unchanged.
    # Off/absent ⇒ ic_kwargs empty ⇒ fast_backtest call is byte-identical (parity). Reuses the L1-champion
    # memoised intra-candle gate + fast_backtest's parity-locked intra-candle path (no new engine code).
    ic_kwargs = {}
    if l2_params.get("l2_intracandle"):
        from optimize.core import _cached_ic_gate
        from indicators import library
        veto_reason = np.zeros(n, dtype=bool)
        for ds in l1.dropped_signals:
            if ds["reason"] == "veto":
                veto_reason[int(ds["idx"])] = True
        veto_ic = l2_gate & veto_reason                       # vetoed candidates → intra-candle timing
        l2_gate = l2_gate & ~veto_reason                      # vol-gated (+ non-veto) → normal candle-close entry
        inds = library.from_specs([s for s in l1.params["indicators"] if s.get("enabled")])
        ic_kwargs = dict(
            intracandle_gate_by_dir=_cached_ic_gate(l1.df1, inds, int(l1.params["k"])),
            intracandle_veto_mask=veto_ic,
            intracandle_vol_gate=veto_ic,                     # True exactly at vetoed IC candidates (vol-passed)
            intracandle_max_wait=int(l2_params.get("l2_intracandle_max_wait", 240)))
    elif l2_params.get("l2_intracandle_self"):
        # E3b (cheap probe): rescue L2's OWN vetoed signals mid-candle when L2's OWN veto clears. These bars are
        # already EXCLUDED from l2_gate (¬veto in eligibility) ⇒ gate=False ⇒ fast_backtest's intra-candle path
        # picks them up. Uses L2's own indicators for both the veto set and the intra-candle gate (memoised once).
        from optimize.core import _cached_ic_gate
        from indicators import library
        _vg, _vt, _cf, *_ = _nq_components(l1, l2_params)
        _base = dropped_mask & l1_flat & _vg & _cf
        if bar_mask is not None:
            _base = _base & np.asarray(bar_mask, dtype=bool)[:n]
        self_veto = _base & _vt                               # L2 vol+confirm pass, but L2's own veto fires
        l2i = library.from_specs([s for s in l2_params.get("indicators", []) if s.get("enabled")])
        ic_kwargs = dict(
            intracandle_gate_by_dir=_cached_ic_gate(l1.df1, l2i, int(l2_params.get("k", 1))),
            intracandle_veto_mask=self_veto, intracandle_vol_gate=self_veto,
            intracandle_max_wait=int(l2_params.get("l2_intracandle_max_wait", 240)))

    _cap_mode = str(l2_params.get("cap_mode") or "none")
    if _cap_mode == "eod":
        from optimize.trading_days import eod_targets
        _eod_t, _eod_sl = eod_targets(d1["Date"].to_numpy(), int(l2_params.get("eod_margin_min", 15) or 15))
    else:
        _eod_t = _eod_sl = None
    cand = fast_backtest(
        dec_dates, dec_close, l1.sig_int, l2_gate,
        d1["Date"].to_numpy(), d1["High"].to_numpy(float),
        d1["Low"].to_numpy(float), d1["Close"].to_numpy(float),
        float(l2_params["sl_soft"]), float(l2_params["sl_hard"]), float(l2_params["tp"]),
        bool(l2_params.get("flip", False)),
        cap_1min=int(l2_params.get("cap_1min", 0) or 0),
        cap_mode=_cap_mode, eod_target=_eod_t, session_last=_eod_sl,
        **ic_kwargs,
        **{k: l2_params.get(k) for k in ("long_sl_soft", "long_sl_hard", "long_tp",
                                         "short_sl_soft", "short_sl_hard", "short_tp")})

    if exit_mode == "keep_l2":
        cand_fc = cand                                       # L2 runs to its own exit; L1 yields
    else:
        l1_entries = [int(t["entry_idx"]) for t in l1.ledger]
        cand_fc = force_close_on_l1_entry(cand, l1_entries, dec_dates, dec_close, pv)
    taken, skipped, n_locks = apply_breaker(cand_fc, pv, float(l2_params.get("dd_limit", 0.0)),
                                            int(l2_params.get("cooldown", 0)))

    # label direction vs the box and count forced exits
    n_l1_exit = 0
    for t in taken:
        box_long = l1.sig_int[int(t["entry_idx"]) - 1] == 1
        t["l2_dir_vs_box"] = "agree" if (box_long == (t["direction"] == "long")) else "oppose"
        if t["exit_reason"] == "L1-entry":
            n_l1_exit += 1

    return L2Result(params=dict(l2_params), ledger=taken, n_skipped_breaker=skipped,
                    n_locks=n_locks, n_l1_entry_exits=n_l1_exit)
